=========================
WSGI Application Profiler
=========================

.. automodule:: werkzeug.contrib.profiler

.. autoclass:: MergeStream

.. autoclass:: ProfilerMiddleware

.. autofunction:: make_action
